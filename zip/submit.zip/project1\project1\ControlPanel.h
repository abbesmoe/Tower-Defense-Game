/**
 * \file ControlPanel.h
 *
 * \author Jacob Riggs
 *
 * 
 */


#pragma once
#include <memory>
#include <string>
#include "Item.h"

class CGame;

/**
 * 
 */
class CControlPanel
{
public:
    CControlPanel(CGame* game);

    /// Default constructor (disabled)
    CControlPanel() = delete;

    /// Copy constructor (disabled)
    CControlPanel(const CControlPanel&) = delete;

    ~CControlPanel();

    void DrawSidebar(std::unique_ptr<Gdiplus::Bitmap>& image, std::wstring filename, int X, int Y, Gdiplus::Graphics* graphics);

    std::shared_ptr<CItem> HitTest(int width, int heightTowerEight, int heightRing, int heightBomb, int x, int y);

    void CControlPanel::TowerDraw(std::shared_ptr<CItem>& item, Gdiplus::Graphics* graphics);

private:
    /// The game this item is contained in
    CGame* mGame;

    /// Image for tower eight
    std::unique_ptr<Gdiplus::Bitmap> mTowerEight;

    /// Image for ring tower
    std::unique_ptr<Gdiplus::Bitmap> mRingTower;

    /// Image for bomb
    std::unique_ptr<Gdiplus::Bitmap> mBomb;

    /// Image for go
    std::unique_ptr<Gdiplus::Bitmap> mGo;
};

