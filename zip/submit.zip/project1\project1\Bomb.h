/**
* \file Bomb.h
*
* \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
*
*  Class that implements a bomb tower
*/


#pragma once

#include "Game.h"
#include "Item.h"

/**
 * Class that implements the bomb tower.
 */
class CBomb : public CItem
{
public:

    /** Accept a visitor
     * param visitor The visitor we accept */
    //virtual void Accept(CTowerVisitor* visitor) override { visitor->VisitTower(this); }

    CBomb(CGame* game);

    ///  Default constructor (disabled)
    CBomb() = delete;

    ///  Copy constructor (disabled)
    CBomb(const CBomb&) = delete;

    ~CBomb();

    /** Is this bomb exploded?
     * \return true if so */
    bool Exploded() { return mExploded; }

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node);
    virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node);

    virtual void CBomb::Tower(std::wstring file, double X, double Y) override;

private:
    /// default bomb explosion time = ???
    int mExplosionTime = 0;

    /// Is this bomb exploded?
    bool mExploded = false;
};

