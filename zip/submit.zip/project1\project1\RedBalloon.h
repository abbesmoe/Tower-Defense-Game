/**
 * \file RedBalloon.h
 *
 * \author Alan Wagner
 *
 * Base class for Red Balloon
 */

#pragma once
#include "Balloon.h"

 /**
  * Class that implements the blue balloon.
  */
class CRedBalloon : public CBalloon
{
public:
    CRedBalloon(CGame* game);

    virtual std::shared_ptr<xmlnode::CXmlNode>
        XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    /// Default constructor (disabled)
    CRedBalloon() = delete;

    /// Copy constructor (disabled)
    CRedBalloon(const CRedBalloon&) = delete;

};



