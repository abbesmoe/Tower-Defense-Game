#pragma once
#include <string>

class CGame;

class CItemNode
{
public:
    CItemNode(CGame* game);

    ///  Default constructor (disabled)
    CItemNode() = delete;

    ///  Copy constructor (disabled)
    CItemNode(const CItemNode&) = delete;

    ~CItemNode();

    void SetId(std::wstring id) { mId = id; }

    void SetItemImage(std::wstring itemImage) { mItemImage = itemImage; }

    void SetRoadType(std::wstring roadType) { mRoadType = roadType; }

    void SetName(std::wstring name) { mName = name; }

private:
    /// The game this item is contained in
    CGame* mGame;

    /// Item name
    std::wstring mName;

    /// Item Id
    std::wstring mId;

    /// Image 
    std::wstring mItemImage;

    /// Type of Road
    std::wstring mRoadType;
};

