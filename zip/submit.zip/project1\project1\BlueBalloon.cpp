
/**
 * \file BlueBalloon.cpp
 *
 * \author Alan Wagner
 */

#include "pch.h"
#include "BlueBalloon.h"
using namespace std;
using namespace Gdiplus;

/// the string that holds the blue balloon image.
const wstring BlueBalloonImageName = L"images/blue-balloon.png";
const double speed = 4;
const int lives = 2;

/** Constructor
* \param game The game this is a member of
*/
CBlueBalloon::CBlueBalloon(CGame* game) : CBalloon(game, BlueBalloonImageName)
{
    SetSpeed(speed);
    SetPopped(false);
    SetLives(lives);
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CBlueBalloon::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);
    return itemNode;
}








