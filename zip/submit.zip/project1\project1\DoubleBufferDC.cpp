#include "pch.h"
#include "DoubleBufferDC.h"
