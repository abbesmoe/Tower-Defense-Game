/**
 * \file Declaration.h
 *
 * \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
 *
 * contains declations
 */

#pragma once
#include <string>
#include "XmlNode.h"

class CGame;

/**
* Class that implements declarations
*/
class CDeclaration
{
public:
    CDeclaration(CGame* game, std::shared_ptr<xmlnode::CXmlNode> node);

    ///  Default constructor (disabled)
    CDeclaration() = delete;

    ///  Copy constructor (disabled)
    CDeclaration(const CDeclaration&) = delete;

    ~CDeclaration();

    /// pass the declarations to display the item
    void Display(std::shared_ptr<xmlnode::CXmlNode> node);

    std::wstring GetId() { return mId; }

private:
    CGame* mGame;
    
    /// Item Id
    std::wstring mId;

    /// Image 
    std::wstring mItemImage;

    /// Type of Road
    std::wstring mRoadType;
};

