/**
 * \file TileTree.cpp
 *
 * \author Moez Abbes
 */

#include "pch.h"
#include "TileTree.h"
#include "Declaration.h"
#include <vector>
#include <string>

 /** Constructor
  * \param game The game this is a member of
  */
CTileTree::CTileTree(CGame* game) : CTile(game)
{
}

/**
*  Destructor
*/
CTileTree::~CTileTree()
{
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CTileTree::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CTile::XmlSave(node);
    return itemNode;
}

/**
* brief Load the attributes for an item node.
* \param node The Xml node we are loading the item from
*/
void CTileTree::XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node, std::wstring itemImage, std::wstring roadType)
{
    CTile::XmlLoad(node, itemImage, roadType);
    SetImage(itemImage);
}