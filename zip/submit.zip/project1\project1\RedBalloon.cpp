/**
 * \file RedBalloon.cpp
 *
 * \author Alan Wagner
 */

#include "pch.h"
#include "RedBalloon.h"
using namespace std;
using namespace Gdiplus;

/// the string that holds the red balloon image.
const wstring RedBalloonImageName = L"images/red-balloon.png";
const double speed = 5.5;
const int lives = 1;

/** Constructor
* \param game The game this is a member of
*/
CRedBalloon::CRedBalloon(CGame* game) : CBalloon(game, RedBalloonImageName)
{
    SetSpeed(speed);
    SetPopped(false);
    SetLives(lives);
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CRedBalloon::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);
    return itemNode;
}



