/**
 * \file BlueBalloon.h
 *
 * \author Alan Wagner
 *
 * Base class for Blue Balloon
 */

#pragma once
#include "Balloon.h"


/**
 * Class that implements the blue balloon.
 */
class CBlueBalloon : public CBalloon
{
public:
    CBlueBalloon(CGame* game);

    virtual std::shared_ptr<xmlnode::CXmlNode>
        XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    /// Default constructor (disabled)
    CBlueBalloon() = delete;

    /// Copy constructor (disabled)
    CBlueBalloon(const CBlueBalloon&) = delete;

};












