/**
 * \file BlackBalloon.cpp
 *
 * \author Alan Wagner
 */

#include "pch.h"
#include "BlackBalloon.h"
using namespace std;
using namespace Gdiplus;

/// the string that holds the black balloon image.
const wstring BlackBalloonImageName = L"images/black-balloon.png";
const double speed = 8;
const int lives = 1;

/** Constructor
* \param game The game this is a member of
*/
CBlackBalloon::CBlackBalloon(CGame* game) : CBalloon(game, BlackBalloonImageName)
{
    SetSpeed(speed);
    SetPopped(false);
    SetLives(lives);
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CBlackBalloon::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);
    return itemNode;
}
