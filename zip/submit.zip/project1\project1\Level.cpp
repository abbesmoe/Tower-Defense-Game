/**
 * \file Level.cpp
 *
 * \author Jacob Riggs
 */

#include "pch.h"
#include "Level.h"
#include "Game.h"


/**
 * Constructor for a level. 
 * \param game game that the level is part of
 */
CLevel::CLevel(CGame* game)
{
}

/**
*  Destructor
*/
CLevel::~CLevel()
{
}