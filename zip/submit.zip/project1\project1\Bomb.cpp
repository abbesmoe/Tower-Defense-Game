/**
 * \file Bomb.cpp
 *
 * \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
 */
#include "pch.h"
#include "Bomb.h"

using namespace std;
using namespace Gdiplus;


/// the file name for the bomb image
const wstring BombImageName = L"images/tower-bomb.png";

/** Constructor
* \param game The game this is a member of
*/
CBomb::CBomb(CGame* game) : CItem(game, BombImageName)
{
}

/**
*  Destructor
*/
CBomb::~CBomb()
{
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CBomb::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);

    itemNode->SetAttribute(L"type", L"bomb");
    itemNode->SetAttribute(L"explosion time", mExplosionTime);
    itemNode->SetAttribute(L"exploded", mExploded);
    return itemNode;
}


/**
* brief Load the attributes for an item node.
* \param node The Xml node we are loading the item from
*/
void CBomb::XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    CItem::XmlLoad(node);
    mExplosionTime = node->GetAttributeIntValue(L"explosion time", 0);
    mExploded = node->GetAttributeIntValue(L"exploded", 0);
}

void CBomb::Tower(std::wstring file, double X, double Y) 
{
    CItem::Tower(file, X, Y);
    SetImage(file);
}