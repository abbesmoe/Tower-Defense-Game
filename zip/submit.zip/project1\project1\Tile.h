/**
 * \file Tile.h
 *
 * \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
 *
 * Base class for any tile in our game
 */

#pragma once

#include "Declaration.h"
#include "XmlNode.h"
#include <string>
#include <memory>
#include <vector>

class CGame;

/**
*  Implements the Tiles
*/
class CTile
{
public:
    /// How much we offset drawing the tile to the left of the center
    const static int OffsetLeft = 612;

    /// How much we offset drawing the tile above the center
    const static int OffsetDown = 1024;

    ///  Default constructor (disabled)
    CTile() = delete;

    ///  Copy constructor (disabled)
    CTile(const CTile&) = delete;

    virtual ~CTile();

    /** The directory were the images are stored */
    static const std::wstring ImagesDirectory;

    void SetImage(const std::wstring& file);

    /**  Draw this item
    * \param graphics The graphics context to draw on */
    virtual void Draw(Gdiplus::Graphics* graphics);

    /**  Test this item to see if it has been clicked on
    * \param x X location on the aquarium to test
    * \param y Y location on the aquarium to test
    * \return true if clicked on */
    virtual bool HitTest(int x, int y);

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node);
    virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node, std::wstring itemImage, std::wstring roadType);

    std::shared_ptr<CTile> GetAdjacent(int dx, int dy);

    /// Handle updates for animation
    /// \param elapsed The time since the last update
    virtual void Update(double elapsed) {}

    /**  The X location of the center of the tile
    * \returns X location in pixels */
    int GetX() const { return mX*64; }

    /**  The Y location of the center of the tile
    * \returns Y location in pixels */
    int GetY() const { return mY*64; }

    /**  Set the item location
    * \param x X location
    * \param y Y location */
    void SetLocation(int x, int y) { mX = x; mY = y; }

    ///  Get the game this item is in
    /// \returns Game pointer
    CGame* GetGame() { return mGame; }

    /**  Get the file name for this tile image
     * \returns Filename or blank if none */
    std::wstring GetFile() { return mFile; }

    std::vector<std::shared_ptr<CDeclaration> > GetDeclaration() { return mDeclarations; }

    void AddDeclaration(std::shared_ptr<CDeclaration> declaration) { 
        mDeclarations.push_back(declaration);
    }

protected:
    CTile(CGame* game);

private:
    /// The game this item is contained in
    CGame* mGame;

    // Item location in the aquarium
    int mX = 0;     ///< X location for the center of the item
    int mY = 0;     ///< Y location for the center of the item

    /// The file for this item
    std::wstring mFile;

    /// The image of this tile
    std::unique_ptr<Gdiplus::Bitmap> mItemImage;

    /// Tile ID
    std::string mId;

    /// Check if Tile is open
    bool mOpen = true;

    /// All of the tiles that make up our city
    std::vector<std::shared_ptr<CDeclaration> > mDeclarations;
};
