/**
 * \file Game.h
 *
 * \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
 *
 *  Class that implements the tower game
 */

#pragma once

#include <memory>
#include <vector>
#include <map>
#include <utility>

#include "XmlNode.h"
#include "Tile.h"
#include "Declaration.h"
#include "Item.h"

 /**
  *  Implements the tower game
  */
class CGame
{

public:
	CGame();
	virtual ~CGame();

    /// The spacing between grid locations
    static const int GridSpacing = 32;


    void AddTile(std::shared_ptr<CTile> item) { mTiles.push_back(item); }
    void AddItem(std::shared_ptr<CItem> item) { mItems.push_back(item); }

    std::vector<std::shared_ptr<CTile> > GetTile() { return mTiles; }
    std::vector<std::shared_ptr<CItem> > GetItem() { return mItems; }

    void MoveToFront(std::shared_ptr<CTile> item);
    void DeleteItem(std::shared_ptr<CTile> item);

    void OnDraw(Gdiplus::Graphics* graphics, int width, int height);

    std::shared_ptr<CItem> HitTest(int width, int heightTowerEight, int heightRing, int heightBomb, int x, int y);

    void Save(const std::wstring& filename);
    void Load(const std::wstring& filename);
    void Clear();

    void Update(double elapsed);
    void SortTiles();

    std::shared_ptr<CTile> GetAdjacent(std::shared_ptr<CTile> tile, int dx, int dy);
    std::shared_ptr<CTile> GetAdjacent(CTile* tile, int dx, int dy);

    void OnLButtonDown(int x, int y);

private:

    //void XmlItem(const std::shared_ptr<CXmlNode>& node);
    void BuildAdjacencies();

    /// All of the tiles that make up our city
    std::vector<std::shared_ptr<CTile> > mTiles;

    /// All of the tiles that make up our city
    std::vector<std::shared_ptr<CItem> > mItems;

    /// Adjacency lookup support
    std::map<std::pair<int, int>, std::shared_ptr<CTile> > mAdjacency;

    // int mPos = 0;

    /// scale of window
    float mScale = 0;
    /// offsetting x value specific amount
    float mXOffset = 0;
    /// offsetting y value specific amount
    float mYOffset = 0;
};

