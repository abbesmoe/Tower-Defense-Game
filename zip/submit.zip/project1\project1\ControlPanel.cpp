/**
 * \file ControlPanel.cpp
 *
 * \author Jacob Riggs
 */



#include "pch.h"
#include "ControlPanel.h"
#include <string>
#include <iostream>
#include <memory>
#include "TowerEight.h"
#include "RingTower.h"
#include "Bomb.h"
using namespace Gdiplus;

CControlPanel::CControlPanel(CGame* game) : mGame(game)
{
}

CControlPanel::~CControlPanel()
{
}

/**
 * Function that draws the pictures of sidebar.
 * param filename Filename of the image
 * param X X axis
 * param Y Y axis
 * param graphics Graphics we are drawing on
 */
void CControlPanel::DrawSidebar(std::unique_ptr<Gdiplus::Bitmap>& image, std::wstring filename,
	int X, int Y, Gdiplus::Graphics* graphics)
{
    
	image = std::unique_ptr<Bitmap>(Bitmap::FromFile(filename.c_str()));

	if (image->GetLastStatus() != Ok)
	{
		std::wstring msg(L"Failed to open ");
		msg += filename;
		AfxMessageBox(msg.c_str());
	}


	graphics->DrawImage(image.get(), X, Y,
		image->GetWidth(), image->GetHeight());
}


/**  Test an x,y click location to see if it clicked
* on some item in the game.
* \param x X location
* \param y Y location
* \returns Pointer to item we clicked on or nullptr if none.
*/
std::shared_ptr<CItem> CControlPanel::HitTest(int width, int heightTowerEight, int heightRing, int heightBomb, int x, int y)
{
    int wid = 50;
    int hit = 50;
    // Make x and y relative to the top-left corner of the bitmap image.
    // Subtracting the center makes x, y relative to the center of 
    // the image. Adding half the size makes x, y relative to the top 
    // corner of the image.
    int testX = x - width + wid;
    int testYTowerEight = y - heightTowerEight + hit;
    int testYRingTower = y - heightRing + hit;
    int testYBombTower = y - heightBomb + hit;

    std::shared_ptr<CItem> item;

    // Test to see if x, y are in the image
    if (testX >= 0 && testYTowerEight >= 0 && testX < wid && testYTowerEight < hit)
    {
        // We are inside the image
        item = std::make_shared<CTowerEight>(mGame);

        item->Tower(L"tower8.png", width, heightTowerEight);

    }
    else if (testX >= 0 && testYRingTower >= 0 && testX < wid && testYRingTower < hit)
    {
        // We are inside the image
        item = std::make_shared<CRingTower>(mGame);

        item->Tower(L"tower-rings.png", width, heightRing);
    }
    else if (testX >= 0 && testYBombTower >= 0 && testX < wid && testYBombTower < hit)
    {
        // We are inside the image
        item = std::make_shared<CBomb>(mGame);

        item->Tower(L"tower-bomb.png", width, heightBomb);
    }

    return item;
}

void CControlPanel::TowerDraw(std::shared_ptr<CItem>& item, Gdiplus::Graphics* graphics)
{
    item->Draw(graphics);
}


