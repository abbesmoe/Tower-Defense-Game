
// ChildView.h : interface of the CChildView class
//


#pragma once
#include "Game.h"


// CChildView window


/**
 * Class that implements the menu and app, handles most commands.
 */
class CChildView : public CWnd
{
// Construction
public:
	CChildView();

// Attributes
public:

// Operations
public:

private:
	/// Instantiate game
	CGame mGame;

	/// True until the first time we draw
	bool mFirstDraw = true;

	long long mLastTime = 0;    ///< Last time we read the timer
	double mTimeFreq = 0;       ///< Rate the timer updates

// Overrides
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildView();

	// Generated message map functions
protected:
	/// Function that will draw when the app is told to
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLevelsLevel1();
	afx_msg void OnLevelsLevel2();
	afx_msg void OnLevelsLevel3();
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

public:
	void CChildView::DrawSidebar(std::unique_ptr<Gdiplus::Bitmap> &image,
			std::wstring filename, int X, int Y, Gdiplus::Graphics *graphics);


private:
	/// Any item we are currently dragging
	std::shared_ptr<CItem> mGrabbedItem;

	/// Image for tower eight
	std::unique_ptr<Gdiplus::Bitmap> mTowerEight;

	/// Image for ring tower
	std::unique_ptr<Gdiplus::Bitmap> mRingTower;

	/// Image for bomb
	std::unique_ptr<Gdiplus::Bitmap> mBomb;

	/// Image for go
	std::unique_ptr<Gdiplus::Bitmap> mGo;


	int mWidth = 0;


	int mHeightTowerEight = 0;


	int mHeightBombTower = 0;


	int mHeightRingTower = 0;


	int mHeightGoButton = 0;
};

