/**
* \file TowerEight.h
*
* \author Moez Abbes
*
*  Class that implements a Tower Eight
*/

#pragma once

#include "Item.h"

/**
*  A Tower Eight
*/
class CTowerEight :
    public CItem
{
public:
    CTowerEight(CGame* game);

    ///  Default constructor (disabled)
    CTowerEight() = delete;

    ///  Copy constructor (disabled)
    CTowerEight(const CTowerEight&) = delete;

    ~CTowerEight();

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    /// Overrides Tower constructor from Item class
    virtual void CTowerEight::Tower(std::wstring file, double X, double Y) override;

    /// Sets the Attack Rate for Tower
    void SetAttackRate(int num) { mAttackRate = num; }

    /// Returns the Attack Rate of the Tower
    int GetAttackRate() { return mAttackRate; }
private:
    /// Tracks the attack rate of the tower
    int mAttackRate = 0;

};

