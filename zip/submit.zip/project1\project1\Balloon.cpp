/**
 * \file Balloon.cpp
 *
 * \author Alan Wagner
 */

#include "pch.h"
#include "Balloon.h"
using namespace std;
using namespace Gdiplus;

/**  Constructor for the balloon
 * \param game the game the we are using
 * \param filename the filename for the image
 */
CBalloon::CBalloon(CGame* game, const std::wstring& filename) : CItem(game,filename)
{
}

/**
*  Destructor
*/
CBalloon::~CBalloon()
{
}

/**
 * Save this item to an XML node
 * \param node The node we are going to be a child of
 * \returns the node that is the balloon
 */
std::shared_ptr<xmlnode::CXmlNode> CBalloon::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = node->AddChild(L"item");

    itemNode->SetAttribute(L"popped", mIsPopped);
    itemNode->SetAttribute(L"speed", mSpeed);
    itemNode->SetAttribute(L"lives", mLives);

    return itemNode;
}

/**
 * Load the attributes for an item node.
 *
 * This is the  base class version that loads the attributes
 * common to all items. Override this to load custom attributes
 * for specific items.
 *
 * \param node The Xml node we are loading the item from
 */
void CBalloon::XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    mIsPopped = node->GetAttributeIntValue(L"popped", 0);
    mSpeed = node->GetAttributeIntValue(L"speed", 0);
    mLives = node->GetAttributeIntValue(L"lives", 0);
}