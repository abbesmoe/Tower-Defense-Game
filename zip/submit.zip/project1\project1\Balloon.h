/**
 * \file Balloon.h
 *
 * \author Alan Wagner
 *
 * Base class for Balloon object
 */

#pragma once
#include "Item.h"


 /**
  * Base class for ballon object
  */
class CBalloon : public CItem
{
public:
    CBalloon(CGame* game, const std::wstring& filename);

    /// Default constructor (disabled)
    CBalloon() = delete;

    /// Copy constructor (disabled)
    CBalloon(const CBalloon&) = delete;

    ///destructor
    ~CBalloon();

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;
    virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node);

    bool IsPopped() { return mIsPopped; }
    void SetPopped(bool popped) { mIsPopped = popped; }
    double GetSpeed() { return mSpeed;  }
    void SetSpeed(double speed) { mSpeed = speed; }
    void SetLives(int lives) { mLives = lives; }
    int GetLives() { return mLives; }


private:
    /// bool that tracks if balloon should be removed
    bool mIsPopped = false;
    /// double that holds the speed of the balloon
    double mSpeed = 0;
    /// integer that tells how many times the balloon can be hit before popping
    int mLives = 1;
};









