#include "pch.h"
#include "TowerEight.h"

using namespace std;
using namespace Gdiplus;

const wstring TowerEightImageName = L"images/tower8.png";

/** Constructor
* \param game The game this is a member of
*/
CTowerEight::CTowerEight(CGame* game) : CItem(game, TowerEightImageName)
{
}

/**
*  Destructor
*/
CTowerEight::~CTowerEight()
{
}

/**  Save this item to an XML node
 * \param node The node we are going to be a child of
 * \returns Pointer to the crated node
 */
std::shared_ptr<xmlnode::CXmlNode> CTowerEight::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);

    itemNode->SetAttribute(L"type", L"road");

    return itemNode;
}


/**
 * Constructs TowerEight with its image along with an x and y location
 * \param file 
 * \param X 
 * \param Y 
 */
void CTowerEight::Tower(std::wstring file, double X, double Y)
{
    CItem::Tower(file, X, Y);
    SetImage(file);
}