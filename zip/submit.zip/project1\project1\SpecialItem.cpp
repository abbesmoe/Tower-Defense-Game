/**
 * \file SpecialItem.cpp
 *
 * \author Alan Wagner
 */

#include "pch.h"
#include "SpecialItem.h"
using namespace std;
using namespace Gdiplus;

/// the string that holds the special balloon image.
const wstring SpecialImageName = L"images/.png";

/** Constructor
* \param game The game this is a member of
*/
CSpecialItem::CSpecialItem(CGame* game) : CBalloon(game, SpecialImageName)
{
}

/**  Save this item to an XML node
* \param node The node we are going to be a child of
* \returns Allocated node
*/
std::shared_ptr<xmlnode::CXmlNode> CSpecialItem::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);
    return itemNode;
}










