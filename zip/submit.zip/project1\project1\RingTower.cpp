#include "pch.h"
#include "RingTower.h"

using namespace std;
using namespace Gdiplus;

const wstring RingTowerImageName = L"images/tower-rings.png";

/** Constructor
* \param game This is a member of CTower(game)
*/
CRingTower::CRingTower(CGame* game) : CItem(game, RingTowerImageName)
{
}

/**
*  Destructor
*/
CRingTower::~CRingTower()
{
}

/**  Save this item to an XML node
 * \param node The node we are going to be a child of
 * \returns Pointer to the crated node
 */
std::shared_ptr<xmlnode::CXmlNode> CRingTower::XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
    auto itemNode = CItem::XmlSave(node);

    itemNode->SetAttribute(L"type", L"ringtower");

    return itemNode;
}

void CRingTower::Tower(std::wstring file, double X, double Y) 
{
    CItem::Tower(file, X, Y);
    SetImage(file);
}