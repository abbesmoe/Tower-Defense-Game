#include "pch.h"
#include "ItemNode.h"
/**  Constructor
* \param game The game this class is a member of
*/
CItemNode::CItemNode(CGame* game) : mGame(game)
{
}
/**
*  Destructor
*/
CItemNode::~CItemNode()
{
}
