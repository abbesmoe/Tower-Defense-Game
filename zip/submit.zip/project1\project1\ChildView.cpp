
// ChildView.cpp : implementation of the CChildView class
//

#include "pch.h"
#include "framework.h"
#include "project1.h"
#include "ChildView.h"
#include "ControlPanel.h"
#include "Game.h"

#include <iostream>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
#include "DoubleBufferDC.h"
using namespace Gdiplus;

/// Frame duration in milliseconds
const int FrameDuration = 30;

// CChildView

CChildView::CChildView()
{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_LEVELS_LEVEL1, &CChildView::OnLevelsLevel1)
	ON_COMMAND(ID_LEVELS_LEVEL2, &CChildView::OnLevelsLevel2)
	ON_COMMAND(ID_LEVELS_LEVEL3, &CChildView::OnLevelsLevel3)
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()



// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{	
	CPaintDC paintDC(this);
	CDoubleBufferDC dc(&paintDC); // device context for painting
	Graphics graphics(dc.m_hDC);

	CRect rect;
	GetClientRect(&rect);

	mGame.OnDraw(&graphics, rect.Width(), rect.Height());

	if (mFirstDraw)
	{
		mFirstDraw = false;
		SetTimer(1, FrameDuration, nullptr);

		/*
		 * Initialize the elapsed time system
		 */
		LARGE_INTEGER time, freq;
		QueryPerformanceCounter(&time);
		QueryPerformanceFrequency(&freq);

		mLastTime = time.QuadPart;
		mTimeFreq = double(freq.QuadPart);
	}

	/*
	 * Compute the elapsed time since the last draw
	 */
	LARGE_INTEGER time;
	QueryPerformanceCounter(&time);
	long long diff = time.QuadPart - mLastTime;
	double elapsed = double(diff) / mTimeFreq;
	mLastTime = time.QuadPart;

	mGame.Update(elapsed);

	mWidth = (900 * rect.Width()) / 1224;

	mHeightTowerEight = (100 * rect.Height() / 1024);

	mHeightRingTower = (300 * rect.Height() / 1024);

	mHeightBombTower = (500 * rect.Height() / 1024);

	mHeightGoButton = (750 * rect.Height() / 1024);

	/*
	 * drawing the sidebar
	 */
	DrawSidebar(mTowerEight, L"images/tower8.png", mWidth, mHeightTowerEight, &graphics);
	DrawSidebar(mRingTower, L"images/tower-rings.png", mWidth, mHeightRingTower, &graphics);
	DrawSidebar(mBomb, L"images/tower-bomb.png", mWidth, mHeightBombTower, &graphics);
	DrawSidebar(mGo, L"images/button-go.png", mWidth, mHeightGoButton, &graphics);

	if (mGrabbedItem != nullptr) 
	{
		auto controlpanel = std::make_shared<CControlPanel>(&mGame);
		controlpanel->TowerDraw(mGrabbedItem, &graphics);
	}
	
}


/**
* Erase the background
*
* This is disabled to eliminate flicker
* \param pDC Device context
* \returns FALSE
*/
BOOL CChildView::OnEraseBkgnd(CDC* pDC)
{
	return FALSE;
}


/**
 * Menu click for level 1 loads level.
 */
void CChildView::OnLevelsLevel1()
{
	CFileDialog dlg(true,  // true = Open dialog box
		L".xml",           // Default file extension
		nullptr,            // Default file name (none)
		0,    // Flags
		L"Game Files (*.xml)|*.xml|All Files (*.*)|*.*||");  // Filter
	if (dlg.DoModal() != IDOK)
		return;

	std::wstring filename = dlg.GetPathName();

	mGame.Load(filename);
	Invalidate();
}


/**
 * Menu click for level 2 loads level.
 */
void CChildView::OnLevelsLevel2()
{
	CFileDialog dlg(true,  // true = Open dialog box
		L".xml",           // Default file extension
		nullptr,            // Default file name (none)
		0,    // Flags
		L"Game Files (*.xml)|*.xml|All Files (*.*)|*.*||");  // Filter
	if (dlg.DoModal() != IDOK)
		return;

	std::wstring filename = dlg.GetPathName();

	mGame.Load(filename);
	Invalidate();
}


/**
 * Menu click for level 3 loads level.
 */
void CChildView::OnLevelsLevel3()
{
	CFileDialog dlg(true,  // true = Open dialog box
		L".xml",           // Default file extension
		nullptr,            // Default file name (none)
		0,    // Flags
		L"Game Files (*.xml)|*.xml|All Files (*.*)|*.*||");  // Filter
	if (dlg.DoModal() != IDOK)
		return;

	std::wstring filename = dlg.GetPathName();

	mGame.Load(filename);
	Invalidate();
}

/**
 * Function that draws the pictures of sidebar.
 * param filename Filename of the image
 * param X X axis
 * param Y Y axis
 * param graphics Graphics we are drawing on
 */
void CChildView::DrawSidebar(std::unique_ptr<Gdiplus::Bitmap> &image,std::wstring filename,
	int X, int Y, Gdiplus::Graphics *graphics)
{
	auto controlpanel = std::make_shared<CControlPanel>(&mGame);
	controlpanel->DrawSidebar(image, filename, X, Y, graphics);
	///std::wcin >> filename;  // input std::wstring

	///const WCHAR* FileStr = filename.c_str(); // Convert to const WCHAR*
	///image = std::unique_ptr<Bitmap>(Bitmap::FromFile(FileStr));

	///if (image->GetLastStatus() != Ok)
	///{
	///	std::wstring msg(L"Failed to open ");
	///	msg += filename;
	///	AfxMessageBox(msg.c_str());
	///}
	

	///graphics->DrawImage(image.get(), X, Y,
	///	image->GetWidth(), image->GetHeight());
}




void CChildView::OnLButtonUp(UINT nFlags, CPoint point)
{
	OnMouseMove(nFlags, point);
}


void CChildView::OnMouseMove(UINT nFlags, CPoint point)
{
	// See if an item is currently being moved by the mouse
	if (mGrabbedItem != nullptr)
	{
		// If an item is being moved, we only continue to 
		// move it while the left button is down.
		if (nFlags & MK_LBUTTON)
		{
			mGrabbedItem->SetLocation(point.x, point.y);
		}
		else
		{
			// When the left button is released, we release the
			// item.
			mGrabbedItem = nullptr;
		}

		// Force the screen to redraw
		Invalidate();
	}
}


void CChildView::OnLButtonDown(UINT nFlags, CPoint point)
{
	mGrabbedItem = mGame.HitTest(mWidth, mHeightTowerEight, mHeightRingTower, mHeightBombTower, point.x, point.y);
	Invalidate();
}
