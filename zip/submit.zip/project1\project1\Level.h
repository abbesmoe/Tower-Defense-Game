/**
 * \file Level.h
 *
 * \author Jacob Riggs
 *
 * Implements the base level class.
 */


#pragma once
#include "Game.h"

/**
 * Class that implements the base level class.
 */
class CLevel
{
public:
    ///  Default constructor (disabled)
    CLevel() = delete;

    ///  Copy constructor (disabled)
    CLevel(const CLevel&) = delete;

    CLevel(CGame* game);

    virtual ~CLevel();


};


