/**
* \file TileRoad.h
*
* \author Moez Abbes
*
*  Class that implements a Road tile
*/

#pragma once

#include "Tile.h"
#include <string>


/**
*  A Road tile
*/
class CTileRoad : public CTile
{
public:
    CTileRoad(CGame* game);

    ///  Default constructor (disabled)
    CTileRoad() = delete;

    ///  Copy constructor (disabled)
    CTileRoad(const CTileRoad&) = delete;

    ~CTileRoad();

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node, std::wstring itemImage, std::wstring roadType);

    /*void SetAdjacencies(bool ul, bool ur, bool ll, bool lr);*/

private:
    /// The current adjacency integer or -1 if none
    int mCurrentAdj = -1;

    std::wstring mRoadType;
};

