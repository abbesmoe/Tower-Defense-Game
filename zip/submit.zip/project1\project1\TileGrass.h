/**
 * \file TileGrass.h
 *
 * \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
 *
 * Contains the grass tiles
 */

#pragma once
#include "Tile.h"

 /**
   * Class that implements grass tiles
   */
class CTileGrass : public CTile
{
public:
    /** Accept a visitor
     * param visitor The visitor we accept */
     //virtual void Accept(CTileVisitor* visitor) override { visitor->VisitTile(this); }

    CTileGrass(CGame* game);

    ///  Default constructor (disabled)
    CTileGrass() = delete;

    ///  Copy constructor (disabled)
    CTileGrass(const CTileGrass&) = delete;

    ~CTileGrass();

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    /** Loads from an xml file
    * \param node node to load in
    */
    virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node, std::wstring itemImage, std::wstring roadType);
};

