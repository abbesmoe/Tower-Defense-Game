/**
 * \file Item.h
 *
 * \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
 *
 * Base class for any item in our game.
 */

//This is a test commit

#pragma once
#include <memory>
#include <string>
#include "XmlNode.h"

class CGame;

 /**
 * Base class for any item in our game.
 */
class CItem
{
public:
    /// Default constructor (disabled)
    CItem() = delete;

    /// Copy constructor (disabled)
    CItem(const CItem&) = delete;

    virtual ~CItem();

    /** The X location of the item
    * \returns X location in pixels */
    virtual double GetX() const { return mX; }

    /** The Y location of the item
    * \returns Y location in pixels */
    virtual double GetY() const { return mY; }

    /// Set the item location
    /// \param x X location
    /// \param y Y location
    void SetLocation(double x, double y) { mX = x; mY = y; }

    void Draw(Gdiplus::Graphics* graphics);

    bool HitTest(int x, int y);

    /// Determine the distance from this item to some other item.
    double CItem::Distance(std::shared_ptr<CItem> other);

    /// Move the item by directly changing x,y by delta amounts
    /// \param dx X amount to move
    /// \param dy Y amount to move
    void Move(double dx, double dy) { mX += dx; mY += dy; }

    /**  Returns a pointer to the game
     * \return pointer to the game
     */
    CGame* GetGame() { return mGame; }

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node);

    /// Load the attributes for an item node. 
    virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node);

    /// Handle updates for animation
    /// param elapsed The time since the last update
    //virtual void Update(double elapsed) {};

    /// Get the width of the game
    /// \returns game width
    int GetWidth() const { return mItemImage->GetWidth(); }

    /// Get the height of the game
    /// \returns game height
    int GetHeight() const { return mItemImage->GetHeight(); }

    /// Get the file path
    /// \returns string of file
    std::wstring GetFile() { return mFile; }

    virtual void Tower(std::wstring file, double X, double Y);

    void SetImage(const std::wstring& file);

protected:
    CItem(CGame* game, const std::wstring& filename);

private:
    /// The game this item is contained in
    CGame* mGame;

    // Item location in the game
    double  mX = 0;     ///< X location for the center of the item
    double  mY = 0;     ///< Y location for the center of the item

    /// The image of this fish
    std::unique_ptr<Gdiplus::Bitmap> mItemImage;


    /// The file to load from
    const std::wstring mFile;
};

