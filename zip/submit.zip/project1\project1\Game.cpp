/**
 * \file Game.cpp
 *
 * \author Moez Abbes, Jacob Riggs, Alan Reed Wagner, Bryan Vi, Mingzhe Huang
 */

#include "pch.h"
#include <algorithm>

#include "Game.h"
#include "Tile.h"
#include "Item.h"
#include "TileGrass.h"
#include "TileRoad.h"
#include "XmlLoader.h"
#include "ControlPanel.h"

using namespace Gdiplus;
using namespace std;
using namespace xmlnode;

/// Game area in virtual pixels
const static int Width = 1224;

/// Game area height in virtual pixels
const static int Height = 1024;

CGame::CGame()
{
}


CGame::~CGame()
{
}



/**
 * Draw the game area
 * \param graphics The GDI+ graphics context to draw on
 * \param width Width of the client window
 * \param height Height of the client window
 */
void CGame::OnDraw(Gdiplus::Graphics* graphics, int width, int height)
{
    // Fill the background with black
    SolidBrush brush(Color::Black);
    graphics->FillRectangle(&brush, 0, 0, width, height);

    //
    // Automatic Scaling
    //
    float scaleX = float(width) / float(Width);
    float scaleY = float(height) / float(Height);
    mScale = min(scaleX, scaleY);

    // Ensure it is centered horizontally
    mXOffset = (float)((width - Width * mScale) / 2);

    // Ensure it is centered vertically
    mYOffset = (float)((height - Height * mScale) / 2);

    graphics->TranslateTransform(mXOffset, mYOffset);
    graphics->ScaleTransform(mScale, mScale);

    for (auto tile : mTiles)
    {
        tile->Draw(graphics);
    }
}

/**  Test an x,y click location to see if it clicked
* on some item in the game.
* \param x X location
* \param y Y location
* \returns Pointer to item we clicked on or nullptr if none.
*/
std::shared_ptr<CItem> CGame::HitTest(int width, int heightTowerEight, int heightRing, int heightBomb, int x, int y)
{
    auto controlpanel = std::make_shared<CControlPanel>(this);
    return controlpanel->HitTest(width, heightTowerEight, heightRing, heightBomb, x, y);
}


/**  Move an item to the front of the list of items.
*
* Removes item from the list and adds it to the end so it
* will display last.
* \param item The item to move
*/
void CGame::MoveToFront(std::shared_ptr<CTile> item)
{
    auto loc = find(::begin(mTiles), ::end(mTiles), item);
    if (loc != ::end(mTiles))
    {
        mTiles.erase(loc);
    }

    mTiles.push_back(item);
}


/**  Delete an item from the aquarium
*
* \param item The item to delete.
*/
void CGame::DeleteItem(std::shared_ptr<CTile> item)
{
    auto loc = find(::begin(mTiles), ::end(mTiles), item);
    if (loc != ::end(mTiles))
    {
        mTiles.erase(loc);
    }
}


/**  Handle updates for animation
* \param elapsed The time since the last update
*/
void CGame::Update(double elapsed)
{
    for (auto item : mTiles)
    {
        item->Update(elapsed);
    }
}

/**  Save the city as a .city XML file.
*
* Open an XML file and stream the city data to it.
*
* \param filename The filename of the file to save the city to
*/
void CGame::Save(const std::wstring& filename)
{
    //
    // Create an XML document
    //
    auto root = CXmlNode::CreateDocument(L"city");

    // Iterate over all items and save them
    for (auto item : mTiles)
    {
        item->XmlSave(root);
    }

    try
    {
        root->Save(filename);
    }
    catch (CXmlNode::Exception ex)
    {
        AfxMessageBox(ex.Message().c_str());
    }
}


/**  Load the city from a .city XML file.
*
* Opens the XML file and reads the nodes, creating items as appropriate.
*
* \param filename The filename of the file to load the city from.
*/
void CGame::Load(const std::wstring& filename)
{
    // We surround with a try/catch to handle errors
    try
    {
        auto xmlLoader = std::make_shared<CXmlLoader>(this);
        xmlLoader->Load(filename);
    }
    catch (CXmlNode::Exception ex)
        {
            AfxMessageBox(ex.Message().c_str());
        }
}

/**
*  Clear the city data.
*
* Deletes all known items in the city.
*/
void CGame::Clear()
{
    mTiles.clear();
}




/**
 *  Ensure the tiles are in the correct drawing order.
 *
 * This draws bottom to top so the tiles can overlapp.
 * Also builds the adjacency support since this is called whenever
 * the city is reorganized.
 */
void CGame::SortTiles()
{
    // sort using a lambda expression 
    sort(::begin(mTiles), ::end(mTiles),
        [](const shared_ptr<CTile>& a, const shared_ptr<CTile>& b) {
            if (a->GetY() < b->GetY())
                return true;

            if (a->GetY() > b->GetY())
                return false;

            return a->GetX() > b->GetX();
        });

    BuildAdjacencies();
}


/**
 *  Build support for fast adjacency testing.
 *
 * This builds a map of the grid locations of every tile, so we can
 * just look them up.
 */
void CGame::BuildAdjacencies()
{
    mAdjacency.clear();
    for (auto tile : mTiles)
    {
        mAdjacency[pair<int, int>(tile->GetX() / GridSpacing,
            tile->GetY() / GridSpacing)] = tile;
    }
}



/**
 *  Get any adjacent tile.
 *
 * Given a tile in the city, this determines if there is another
 * tile adjacent to it. The parameters dx, dy determine which direction
 * to look.
 *
 * The values for specific adjacencies (dx, dy, and direction):
 *    - -1 -1 Upper left
 *    - 1 -1 Upper right
 *    - -1 1 Lower left
 *    - 1 1 Lower right
 *
 * \param tile Tile to test
 * \param dx Left/right determination, -1=left, 1=right
 * \param dy Up/Down determination, -1=up, 1=down
 * \returns Adjacent tile or nullptr if none.
 */
std::shared_ptr<CTile> CGame::GetAdjacent(std::shared_ptr<CTile> tile, int dx, int dy)
{
    return GetAdjacent(tile.get(), dx, dy);
}

/**
 *  Get any adjacent tile.
 *
 * Identical to the other version, except this version accepts a
 * regular pointer instead of a shared_ptr. This allows the function
 * to be called from CTile, which only knows itself as a pointer.
 *
 * \param tile Tile to test
 * \param dx Left/right determination, -1=left, 1=right
 * \param dy Up/Down determination, -1=up, 1=down
 * \returns Adjacent tile or nullptr if none.
 */
std::shared_ptr<CTile> CGame::GetAdjacent(CTile* tile, int dx, int dy)
{
    int atX = tile->GetX() / GridSpacing + dx * 2;
    int atY = tile->GetY() / GridSpacing + dy;

    auto adj = mAdjacency.find(pair<int, int>(atX, atY));
    if (adj != mAdjacency.end())
    {
        // We found it
        return adj->second;
    }

    //int atX = tile->GetX() + dx * GridSpacing * 2;
    //int atY = tile->GetY() + dy * GridSpacing;

    //for (auto testTile : mTiles)
    //{
    //    if (testTile->GetX() == atX &&
    //        testTile->GetY() == atY)
    //    {
    //        return testTile;
    //    }
    //}

    // If nothing found
    return nullptr;
}

/**
* Handle a click on the game area
* \param x X location clicked on
* \param y Y location clicked on
*/
void CGame::OnLButtonDown(int x, int y)
{
    double oX = (x - mXOffset) / mScale;
    double oY = (y - mYOffset) / mScale;
}