

/**
 * \file BlackBalloon.h
 *
 * \author Alan Wagner
 *
 * Base class for Black Balloon
 */

#pragma once
#include "Balloon.h"

/**
 * Class that implements the black balloon.
 */
class CBlackBalloon : public CBalloon
{
public:
    CBlackBalloon(CGame* game);

    virtual std::shared_ptr<xmlnode::CXmlNode>
        XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    /// Default constructor (disabled)
    CBlackBalloon() = delete;

    /// Copy constructor (disabled)
    CBlackBalloon(const CBlackBalloon&) = delete;

};






