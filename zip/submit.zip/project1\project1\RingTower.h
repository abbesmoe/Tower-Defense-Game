/**
* \file RingTower.h
*
* \author Bryan Vi
*
*  Class that implements a Tower Eight
*/

#pragma once

#include "Item.h"

/**
*  A Ring Tower
*/
class CRingTower :
    public CItem
{
public:
    CRingTower(CGame* game);

    ///  Default constructor (disabled)
    CRingTower() = delete;

    ///  Copy constructor (disabled)
    CRingTower(const CRingTower&) = delete;

    ~CRingTower();

    virtual std::shared_ptr<xmlnode::CXmlNode> XmlSave(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

    virtual void CRingTower::Tower(std::wstring file, double X, double Y) override;
private:
    /// tracks the attack rate of the ring tower
    int mAttackRate = 0;

};

